import express from "express";
import {
  listAllCases,
  getCaseDetails,
  updateCaseStatus,
  getAvailableStatuses,
  viewClientProfile,
  listClients,
} from "../controllers/designer/index.js";
import { authenticate } from "../middleware/auth.middleware.js";
import { requireDesigner } from "../middleware/authorization.middleware.js";

const router = express.Router();

// All routes require authentication + designer role
router.use(authenticate);
router.use(requireDesigner);

// Case routes
router.get("/cases", listAllCases);
router.get("/cases/:id", getCaseDetails);
router.put("/cases/:id/status", updateCaseStatus);
router.get("/cases/:id/available-statuses", getAvailableStatuses);

// Client profile routes
router.get("/clients", listClients);
router.get("/clients/:id", viewClientProfile);

export default router;
