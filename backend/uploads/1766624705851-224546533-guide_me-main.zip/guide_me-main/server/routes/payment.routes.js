import express from "express";
import {
  uploadStudyPaymentProof,
  uploadProductionPaymentProof,
  requestRefund,
  listPayments,
  getPayment,
} from "../controllers/payment/index.js";
import { authenticate } from "../middleware/auth.middleware.js";

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Payment routes
router.post("/study-fee", uploadStudyPaymentProof);
router.post("/production-fee", uploadProductionPaymentProof);
router.post("/:id/refund-request", requestRefund);
router.get("/", listPayments);
router.get("/:id", getPayment);

export default router;
