import express from "express";
import authRoutes from "./auth.routes.js";
import profileRoutes from "./profile.routes.js";
import caseRoutes from "./case.routes.js";
import commentRoutes from "./comment.routes.js";
import fileRoutes from "./file.routes.js";
import quoteRoutes from "./quote.routes.js";
import paymentRoutes from "./payment.routes.js";
import adminRoutes from "./admin.routes.js";
import desginerRoutes from "./designer.routes.js";

const router = express.Router();

// Mount routes
router.use("/auth", authRoutes);
router.use("/profile", profileRoutes);
router.use("/cases", caseRoutes);
router.use("/comments", commentRoutes);
router.use("/files", fileRoutes);
router.use("/quotes", quoteRoutes);
router.use("/payments", paymentRoutes);
router.use("/admin", adminRoutes);
router.use("/designer", desginerRoutes);

export default router;
