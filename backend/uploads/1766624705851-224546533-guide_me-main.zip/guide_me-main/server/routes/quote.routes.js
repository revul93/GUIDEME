import express from "express";
import { listQuotes, getQuote, acceptQuote, rejectQuote } from "../controllers/quote/index.js";
import { authenticate } from "../middleware/auth.middleware.js";

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Quote routes
router.get("/cases/:id/quotes", listQuotes);
router.get("/:id", getQuote);
router.put("/:id/accept", acceptQuote);
router.put("/:id/reject", rejectQuote);

export default router;
