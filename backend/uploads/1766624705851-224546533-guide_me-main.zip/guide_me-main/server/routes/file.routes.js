import express from "express";
import { uploadFile, listFiles, deleteFile } from "../controllers/file/index.js";
import { authenticate } from "../middleware/auth.middleware.js";

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// File routes
router.post("/cases/:id/files", uploadFile);
router.get("/cases/:id/files", listFiles);
router.delete("/:id", deleteFile);

export default router;
