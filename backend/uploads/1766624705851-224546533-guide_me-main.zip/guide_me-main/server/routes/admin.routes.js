import express from "express";
import { authenticate } from "../middleware/auth.middleware.js";
import { requireAdmin } from "../middleware/authorization.middleware.js";
import { createQuote, reviseQuote } from "../controllers/quote/index.js";
import {
  verifyPayment,
  rejectPayment,
  approveRefund,
  rejectRefund,
} from "../controllers/payment/index.js";

const router = express.Router();

// All routes require authentication + admin privileges
router.use(authenticate);
router.use(requireAdmin);

// Admin quote routes
router.post("/quotes", createQuote);
router.put("/quotes/:id", reviseQuote);

// Admin payment routes
router.put("/payments/:id/verify", verifyPayment);
router.put("/payments/:id/reject", rejectPayment);
router.put("/payments/:id/approve-refund", approveRefund);
router.put("/payments/:id/reject-refund", rejectRefund);

// Admin user management routes (future)
// router.post("/designers", createDesigner);
// router.put("/designers/:id", updateDesigner);
// router.delete("/designers/:id", deleteDesigner);

export default router;
