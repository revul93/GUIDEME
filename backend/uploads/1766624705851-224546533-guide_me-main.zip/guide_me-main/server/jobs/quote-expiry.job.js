import prisma from "../config/db.js";
import logger from "../utils/logger.js";

/**
 * Check and expire quotes that have passed their validUntil date
 * Run this job daily at midnight
 */
export const checkExpiredQuotes = async () => {
  try {
    console.log("Running quote expiry check...");

    const now = new Date();

    const expiredQuotes = await prisma.caseQuote.findMany({
      where: {
        validUntil: {
          lt: now,
        },
        isAccepted: false,
        isRejected: false,
        isSent: true,
      },
      include: {
        case: {
          select: {
            id: true,
            status: true,
            caseNumber: true,
          },
        },
      },
    });

    if (expiredQuotes.length === 0) {
      console.log("No expired quotes found");
      return {
        success: true,
        expiredCount: 0,
      };
    }

    console.log(`Found ${expiredQuotes.length} expired quotes`);

    for (const quote of expiredQuotes) {
      if (quote.case.status === "quote_sent") {
        await prisma.case.update({
          where: { id: quote.caseId },
          data: { status: "cancelled" },
        });

        await prisma.caseStatusHistory.create({
          data: {
            caseId: quote.caseId,
            fromStatus: "quote_sent",
            toStatus: "cancelled",
            changedBy: "system",
            changedById: null,
            notes: `Quote expired (validUntil: ${quote.validUntil.toISOString()})`,
          },
        });

        console.log(
          `Case ${quote.case.caseNumber} cancelled due to quote expiry`
        );
      }
    }

    console.log(
      `Quote expiry check completed. ${expiredQuotes.length} quotes expired`
    );

    return {
      success: true,
      expiredCount: expiredQuotes.length,
    };
  } catch (error) {
    logger.error("Quote expiry job error:", error);
    return {
      success: false,
      error: error.message,
    };
  }
};

/**
 * Setup cron job to run daily at midnight
 * Usage: Call this in your server initialization
 */
export const setupQuoteExpiryCron = () => {
  // Run immediately on startup (optional)
  // checkExpiredQuotes();

  // Schedule to run every day at midnight (00:00)
  const runDaily = () => {
    const now = new Date();
    const night = new Date();
    night.setHours(24, 0, 0, 0); // Next midnight

    const msToMidnight = night.getTime() - now.getTime();

    setTimeout(() => {
      checkExpiredQuotes();
      setInterval(checkExpiredQuotes, 24 * 60 * 60 * 1000); // Run every 24 hours
    }, msToMidnight);
  };

  runDaily();
  console.log("✅ Quote expiry cron job scheduled (daily at midnight)");
};

// Alternative: Use node-cron package for more control
// import cron from 'node-cron';
//
// export const setupQuoteExpiryCron = () => {
//   cron.schedule('0 0 * * *', async () => {
//     console.log('Running scheduled quote expiry check...');
//     await checkExpiredQuotes();
//   });
//   console.log('✅ Quote expiry cron job scheduled (daily at midnight)');
// };
