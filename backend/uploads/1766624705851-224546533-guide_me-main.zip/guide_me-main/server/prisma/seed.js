import prisma from "../config/db.js";

async function main() {
  console.log("🌱 Starting database seeding...\n");

  // Clear existing data (optional - comment out in production)
  console.log("🗑️  Clearing existing data...");
  await prisma.caseStatusHistory.deleteMany();
  await prisma.caseComment.deleteMany();
  await prisma.caseFile.deleteMany();
  await prisma.payment.deleteMany();
  await prisma.caseQuote.deleteMany();
  await prisma.case.deleteMany();
  await prisma.address.deleteMany();
  await prisma.clientProfile.deleteMany();
  await prisma.designerProfile.deleteMany();
  await prisma.tokenBlacklist.deleteMany();
  await prisma.otpCode.deleteMany();
  await prisma.loginHistory.deleteMany();
  await prisma.user.deleteMany();
  console.log("✓ Data cleared\n");

  // ========================================
  // 1. Create Admin User
  // ========================================
  console.log("👤 Creating admin user...");

  const adminUser = await prisma.user.create({
    data: {
      email: "admin@guideme.com",
      phoneNumber: "+966500000001",
      role: "designer",
      emailVerified: true,
      phoneVerified: true,
      accountStatus: "active",
    },
  });

  const adminProfile = await prisma.designerProfile.create({
    data: {
      userId: adminUser.id,
      name: "Admin User",
      bio: "System Administrator",
      isAdmin: true,
      canApproveQuotes: true,
      canManageUsers: true,
      canManageCatalog: true,
    },
  });

  console.log(`✓ Admin created: ${adminProfile.name} (${adminUser.email})`);
  console.log(`  Password: Use OTP login with ${adminUser.email}\n`);

  // ========================================
  // 2. Create Designer Users
  // ========================================
  console.log("👥 Creating designer users...");

  const designer1User = await prisma.user.create({
    data: {
      email: "designer1@guideme.com",
      phoneNumber: "+966500000002",
      role: "designer",
      emailVerified: true,
      phoneVerified: true,
      accountStatus: "active",
    },
  });

  const designer1Profile = await prisma.designerProfile.create({
    data: {
      userId: designer1User.id,
      name: "Sarah Ahmed",
      bio: "Senior Dental Designer - 5 years experience",
      isAdmin: false,
      canApproveQuotes: true,
      canManageUsers: false,
      canManageCatalog: false,
    },
  });

  const designer2User = await prisma.user.create({
    data: {
      email: "designer2@guideme.com",
      phoneNumber: "+966500000003",
      role: "designer",
      emailVerified: true,
      phoneVerified: true,
      accountStatus: "active",
    },
  });

  const designer2Profile = await prisma.designerProfile.create({
    data: {
      userId: designer2User.id,
      name: "Mohammed Ali",
      bio: "Junior Dental Designer",
      isAdmin: false,
      canApproveQuotes: false,
      canManageUsers: false,
      canManageCatalog: false,
    },
  });

  console.log(
    `✓ Designer 1: ${designer1Profile.name} (${designer1User.email})`
  );
  console.log(
    `✓ Designer 2: ${designer2Profile.name} (${designer2User.email})\n`
  );

  // ========================================
  // 3. Create Doctor Users
  // ========================================
  console.log("🦷 Creating doctor users...");

  const doctor1User = await prisma.user.create({
    data: {
      email: "doctor1@example.com",
      phoneNumber: "+966501234567",
      role: "client",
      emailVerified: true,
      phoneVerified: true,
      accountStatus: "active",
    },
  });

  const doctor1Profile = await prisma.clientProfile.create({
    data: {
      userId: doctor1User.id,
      clientType: "doctor",
      name: "Dr. Khalid Hassan",
      specialty: "IMPLANTOLOGY",
      clinicName: "Riyadh Dental Center",
    },
  });

  await prisma.address.create({
    data: {
      clientProfileId: doctor1Profile.id,
      label: "Clinic",
      country: "Saudi Arabia",
      city: "Riyadh",
      district: "Olaya",
      street: "King Fahd Road",
      building: "Building 123",
      postalCode: "12345",
      isDefault: true,
    },
  });

  const doctor2User = await prisma.user.create({
    data: {
      email: "doctor2@example.com",
      phoneNumber: "+966502345678",
      role: "client",
      emailVerified: true,
      phoneVerified: true,
      accountStatus: "active",
    },
  });

  const doctor2Profile = await prisma.clientProfile.create({
    data: {
      userId: doctor2User.id,
      clientType: "doctor",
      name: "Dr. Fatima Al-Mansour",
      specialty: "PROSTHODONTICS",
      clinicName: "Jeddah Smile Clinic",
    },
  });

  await prisma.address.create({
    data: {
      clientProfileId: doctor2Profile.id,
      label: "Main Clinic",
      country: "Saudi Arabia",
      city: "Jeddah",
      district: "Al Hamra",
      street: "Tahlia Street",
      building: "Tower 456",
      postalCode: "23456",
      isDefault: true,
    },
  });

  console.log(`✓ Doctor 1: ${doctor1Profile.name} (${doctor1User.email})`);
  console.log(`✓ Doctor 2: ${doctor2Profile.name} (${doctor2User.email})\n`);

  // ========================================
  // 4. Create Lab User
  // ========================================
  console.log("🏭 Creating lab user...");

  const labUser = await prisma.user.create({
    data: {
      email: "lab@example.com",
      phoneNumber: "+966503456789",
      role: "client",
      emailVerified: true,
      phoneVerified: true,
      accountStatus: "active",
    },
  });

  const labProfile = await prisma.clientProfile.create({
    data: {
      userId: labUser.id,
      clientType: "lab",
      name: "Modern Dental Lab",
      clinicName: "Modern Dental Lab - Riyadh Branch",
    },
  });

  console.log(`✓ Lab: ${labProfile.name} (${labUser.email})\n`);

  // ========================================
  // 5. Create Sample Cases
  // ========================================
  console.log("📋 Creating sample cases...");

  // Case 1: Submitted (paid study fee, awaiting designer)
  const case1 = await prisma.case.create({
    data: {
      caseNumber: "CASE-2024-001",
      clientProfileId: doctor1Profile.id,
      patientName: "Ahmed Mohammed",
      patientAge: 45,
      patientGender: "male",
      procedureCategory: "single_implant",
      guideType: "tooth_support",
      requiredService: "full_solution",
      implantSystem: "straumann",
      teethNumbers: JSON.stringify([14]),
      clinicalNotes: "Good bone density, no complications expected",
      status: "submitted",
      isDraft: false,
      submittedAt: new Date(),
    },
  });

  await prisma.payment.create({
    data: {
      paymentNumber: "PAY-2024-001",
      caseId: case1.id,
      clientProfileId: doctor1Profile.id,
      paymentType: "study_fee",
      amount: 100,
      currency: "SAR",
      paymentMethod: "bank_transfer",
      status: "verified",
      proofUrl: "https://example.com/payment-proof-001.jpg",
      proofUploadedAt: new Date(),
      verifiedAt: new Date(),
      verifiedById: adminProfile.id,
    },
  });

  await prisma.caseStatusHistory.create({
    data: {
      caseId: case1.id,
      fromStatus: "pending_study_payment",
      toStatus: "submitted",
      changedBy: "designer",
      changedById: adminProfile.id,
      notes: "Study payment verified",
    },
  });

  // Case 2: In study progress
  const case2 = await prisma.case.create({
    data: {
      caseNumber: "CASE-2024-002",
      clientProfileId: doctor2Profile.id,
      patientName: "Sara Ali",
      patientAge: 35,
      patientGender: "female",
      procedureCategory: "multiple_implant",
      guideType: "bone_support",
      requiredService: "full_solution",
      implantSystem: "nobel_biocare",
      teethNumbers: JSON.stringify([24, 25, 26]),
      clinicalNotes: "Patient requires full arch restoration",
      status: "study_in_progress",
      isDraft: false,
      submittedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000), // 2 days ago
    },
  });

  await prisma.caseComment.create({
    data: {
      caseId: case2.id,
      designerProfileId: designer1Profile.id,
      authorType: "designer",
      comment:
        "Started working on the study. Will have initial results by tomorrow.",
    },
  });

  // Case 3: Study completed, awaiting quote
  const case3 = await prisma.case.create({
    data: {
      caseNumber: "CASE-2024-003",
      clientProfileId: doctor1Profile.id,
      patientName: "Omar Abdullah",
      patientAge: 52,
      patientGender: "male",
      procedureCategory: "full_arch",
      guideType: "tissue_support",
      requiredService: "full_solution",
      implantSystem: "osstem",
      teethNumbers: JSON.stringify([11, 12, 13, 21, 22, 23]),
      clinicalNotes: "Full upper arch restoration needed",
      status: "study_completed",
      isDraft: false,
      submittedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000), // 5 days ago
      studyCompletedById: designer1Profile.id,
    },
  });

  console.log(`✓ Case 1: ${case1.caseNumber} - ${case1.status}`);
  console.log(`✓ Case 2: ${case2.caseNumber} - ${case2.status}`);
  console.log(`✓ Case 3: ${case3.caseNumber} - ${case3.status}\n`);

  // ========================================
  // Summary
  // ========================================
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("✅ Seeding completed successfully!\n");
  console.log("📊 Summary:");
  console.log(`   • Designers: 3 (1 admin, 2 regular)`);
  console.log(`   • Doctors: 2`);
  console.log(`   • Labs: 1`);
  console.log(`   • Cases: 3`);
  console.log(`   • Payments: 1 verified\n`);

  console.log("🔑 Login Credentials:");
  console.log("   All users use OTP login");
  console.log("   Admin: admin@guideme.com");
  console.log("   Designer 1: designer1@guideme.com");
  console.log("   Designer 2: designer2@guideme.com");
  console.log("   Doctor 1: doctor1@example.com");
  console.log("   Doctor 2: doctor2@example.com");
  console.log("   Lab: lab@example.com");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
}

main()
  .catch((e) => {
    console.error("❌ Seeding failed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
