-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_OtpCode" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "userId" INTEGER,
    "identifier" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "purpose" TEXT NOT NULL,
    "expiresAt" DATETIME NOT NULL,
    "isUsed" BOOLEAN NOT NULL DEFAULT false,
    "usedAt" DATETIME,
    "attempts" INTEGER NOT NULL DEFAULT 0,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "OtpCode_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_OtpCode" ("attempts", "channel", "code", "createdAt", "expiresAt", "id", "identifier", "isUsed", "purpose", "usedAt", "userId") SELECT "attempts", "channel", "code", "createdAt", "expiresAt", "id", "identifier", "isUsed", "purpose", "usedAt", "userId" FROM "OtpCode";
DROP TABLE "OtpCode";
ALTER TABLE "new_OtpCode" RENAME TO "OtpCode";
CREATE INDEX "OtpCode_userId_isUsed_expiresAt_idx" ON "OtpCode"("userId", "isUsed", "expiresAt");
CREATE INDEX "OtpCode_identifier_channel_purpose_isUsed_expiresAt_idx" ON "OtpCode"("identifier", "channel", "purpose", "isUsed", "expiresAt");
CREATE INDEX "OtpCode_expiresAt_idx" ON "OtpCode"("expiresAt");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
