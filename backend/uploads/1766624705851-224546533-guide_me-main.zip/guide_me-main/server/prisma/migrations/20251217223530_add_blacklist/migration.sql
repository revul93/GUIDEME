/*
  Warnings:

  - Added the required column `createdById` to the `CaseQuote` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Case" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "caseNumber" TEXT NOT NULL,
    "clientProfileId" INTEGER NOT NULL,
    "patientId" TEXT,
    "patientName" TEXT,
    "patientAge" INTEGER,
    "patientGender" TEXT,
    "procedureCategory" TEXT NOT NULL,
    "guideType" TEXT NOT NULL,
    "requiredService" TEXT NOT NULL,
    "implantSystem" TEXT,
    "implantSystemOther" TEXT,
    "teethNumbers" TEXT,
    "clinicalNotes" TEXT,
    "specialInstructions" TEXT,
    "status" TEXT NOT NULL DEFAULT 'draft',
    "isDraft" BOOLEAN NOT NULL DEFAULT true,
    "submittedAt" DATETIME,
    "studyCompletedAt" DATETIME,
    "studyCompletedById" INTEGER,
    "deliveryMethod" TEXT,
    "deliveryAddressId" INTEGER,
    "pickupBranchId" INTEGER,
    "estimatedDeliveryDate" DATETIME,
    "actualDeliveryDate" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    "completedAt" DATETIME,
    "cancelledAt" DATETIME,
    "cancellationReason" TEXT,
    CONSTRAINT "Case_clientProfileId_fkey" FOREIGN KEY ("clientProfileId") REFERENCES "ClientProfile" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Case_studyCompletedById_fkey" FOREIGN KEY ("studyCompletedById") REFERENCES "DesignerProfile" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Case_deliveryAddressId_fkey" FOREIGN KEY ("deliveryAddressId") REFERENCES "Address" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Case_pickupBranchId_fkey" FOREIGN KEY ("pickupBranchId") REFERENCES "Branch" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_Case" ("actualDeliveryDate", "cancellationReason", "cancelledAt", "caseNumber", "clientProfileId", "clinicalNotes", "completedAt", "createdAt", "deliveryAddressId", "deliveryMethod", "estimatedDeliveryDate", "guideType", "id", "implantSystem", "implantSystemOther", "patientAge", "patientGender", "patientId", "patientName", "pickupBranchId", "procedureCategory", "requiredService", "specialInstructions", "status", "studyCompletedAt", "submittedAt", "teethNumbers", "updatedAt") SELECT "actualDeliveryDate", "cancellationReason", "cancelledAt", "caseNumber", "clientProfileId", "clinicalNotes", "completedAt", "createdAt", "deliveryAddressId", "deliveryMethod", "estimatedDeliveryDate", "guideType", "id", "implantSystem", "implantSystemOther", "patientAge", "patientGender", "patientId", "patientName", "pickupBranchId", "procedureCategory", "requiredService", "specialInstructions", "status", "studyCompletedAt", "submittedAt", "teethNumbers", "updatedAt" FROM "Case";
DROP TABLE "Case";
ALTER TABLE "new_Case" RENAME TO "Case";
CREATE UNIQUE INDEX "Case_caseNumber_key" ON "Case"("caseNumber");
CREATE INDEX "Case_clientProfileId_status_idx" ON "Case"("clientProfileId", "status");
CREATE INDEX "Case_caseNumber_idx" ON "Case"("caseNumber");
CREATE INDEX "Case_status_createdAt_idx" ON "Case"("status", "createdAt");
CREATE INDEX "Case_isDraft_idx" ON "Case"("isDraft");
CREATE TABLE "new_CaseQuote" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "quoteNumber" TEXT NOT NULL,
    "caseId" INTEGER NOT NULL,
    "studyFee" REAL NOT NULL DEFAULT 100,
    "designFee" REAL NOT NULL DEFAULT 0,
    "productionFee" REAL NOT NULL DEFAULT 0,
    "deliveryFee" REAL NOT NULL DEFAULT 0,
    "subtotal" REAL NOT NULL,
    "discountAmount" REAL NOT NULL DEFAULT 0,
    "discountReason" TEXT,
    "vatRate" REAL NOT NULL DEFAULT 15,
    "vatAmount" REAL NOT NULL,
    "totalAmount" REAL NOT NULL,
    "isSent" BOOLEAN NOT NULL DEFAULT false,
    "sentAt" DATETIME,
    "isAccepted" BOOLEAN NOT NULL DEFAULT false,
    "acceptedAt" DATETIME,
    "isRejected" BOOLEAN NOT NULL DEFAULT false,
    "rejectedAt" DATETIME,
    "rejectionReason" TEXT,
    "validUntil" DATETIME,
    "internalNotes" TEXT,
    "notes" TEXT,
    "createdById" INTEGER NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "CaseQuote_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "Case" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "CaseQuote_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "DesignerProfile" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_CaseQuote" ("acceptedAt", "caseId", "createdAt", "deliveryFee", "designFee", "discountAmount", "discountReason", "id", "internalNotes", "isAccepted", "isRejected", "isSent", "notes", "productionFee", "quoteNumber", "rejectedAt", "rejectionReason", "sentAt", "studyFee", "subtotal", "totalAmount", "updatedAt", "validUntil", "vatAmount", "vatRate") SELECT "acceptedAt", "caseId", "createdAt", "deliveryFee", "designFee", "discountAmount", "discountReason", "id", "internalNotes", "isAccepted", "isRejected", "isSent", "notes", "productionFee", "quoteNumber", "rejectedAt", "rejectionReason", "sentAt", "studyFee", "subtotal", "totalAmount", "updatedAt", "validUntil", "vatAmount", "vatRate" FROM "CaseQuote";
DROP TABLE "CaseQuote";
ALTER TABLE "new_CaseQuote" RENAME TO "CaseQuote";
CREATE UNIQUE INDEX "CaseQuote_quoteNumber_key" ON "CaseQuote"("quoteNumber");
CREATE INDEX "CaseQuote_caseId_idx" ON "CaseQuote"("caseId");
CREATE INDEX "CaseQuote_quoteNumber_idx" ON "CaseQuote"("quoteNumber");
CREATE INDEX "CaseQuote_createdById_idx" ON "CaseQuote"("createdById");
CREATE TABLE "new_Payment" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "paymentNumber" TEXT NOT NULL,
    "caseId" INTEGER NOT NULL,
    "quoteId" INTEGER,
    "clientProfileId" INTEGER NOT NULL,
    "paymentType" TEXT NOT NULL,
    "amount" REAL NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'SAR',
    "paymentMethod" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'pending',
    "proofUrl" TEXT,
    "proofUploadedAt" DATETIME,
    "hyperPayCheckoutId" TEXT,
    "hyperPayResourcePath" TEXT,
    "cardLast4" TEXT,
    "cardBrand" TEXT,
    "transactionId" TEXT,
    "transactionDate" DATETIME,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "verifiedById" INTEGER,
    "verifiedAt" DATETIME,
    "rejectionReason" TEXT,
    "isRefunded" BOOLEAN NOT NULL DEFAULT false,
    "refundedAmount" REAL,
    "refundedAt" DATETIME,
    "refundReason" TEXT,
    "notes" TEXT,
    "ipAddress" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "Payment_caseId_fkey" FOREIGN KEY ("caseId") REFERENCES "Case" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT "Payment_quoteId_fkey" FOREIGN KEY ("quoteId") REFERENCES "CaseQuote" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT "Payment_clientProfileId_fkey" FOREIGN KEY ("clientProfileId") REFERENCES "ClientProfile" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "Payment_verifiedById_fkey" FOREIGN KEY ("verifiedById") REFERENCES "DesignerProfile" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
INSERT INTO "new_Payment" ("amount", "cardBrand", "cardLast4", "caseId", "clientProfileId", "createdAt", "currency", "hyperPayCheckoutId", "hyperPayResourcePath", "id", "ipAddress", "isRefunded", "isVerified", "notes", "paymentMethod", "paymentNumber", "paymentType", "proofUploadedAt", "proofUrl", "quoteId", "refundReason", "refundedAmount", "refundedAt", "rejectionReason", "status", "transactionDate", "transactionId", "updatedAt", "verifiedAt") SELECT "amount", "cardBrand", "cardLast4", "caseId", "clientProfileId", "createdAt", "currency", "hyperPayCheckoutId", "hyperPayResourcePath", "id", "ipAddress", "isRefunded", "isVerified", "notes", "paymentMethod", "paymentNumber", "paymentType", "proofUploadedAt", "proofUrl", "quoteId", "refundReason", "refundedAmount", "refundedAt", "rejectionReason", "status", "transactionDate", "transactionId", "updatedAt", "verifiedAt" FROM "Payment";
DROP TABLE "Payment";
ALTER TABLE "new_Payment" RENAME TO "Payment";
CREATE UNIQUE INDEX "Payment_paymentNumber_key" ON "Payment"("paymentNumber");
CREATE INDEX "Payment_caseId_status_idx" ON "Payment"("caseId", "status");
CREATE INDEX "Payment_clientProfileId_idx" ON "Payment"("clientProfileId");
CREATE INDEX "Payment_paymentType_status_idx" ON "Payment"("paymentType", "status");
CREATE INDEX "Payment_transactionId_idx" ON "Payment"("transactionId");
CREATE INDEX "Payment_verifiedById_idx" ON "Payment"("verifiedById");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
