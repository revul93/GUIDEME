# GuideMe API Documentation

**Base URL:** `http://localhost:3000/api`

**Version:** 1.0.0

**Authentication:** Bearer Token (JWT)

---

## Table of Contents

1. [Authentication](#authentication)
2. [Profile Management](#profile-management)
3. [Address Management](#address-management)
4. [Case Management](#case-management)
5. [Comments](#comments)
6. [File Management](#file-management)
7. [Quotes](#quotes)
8. [Payments](#payments)
9. [Designer Endpoints](#designer-endpoints)
10. [Admin Endpoints](#admin-endpoints)
11. [Error Codes](#error-codes)

---

## Authentication

All authenticated endpoints require the `Authorization` header:
```
Authorization: Bearer <access_token>
```

### 1. Request OTP

**Endpoint:** `POST /auth/request-otp`

**Description:** Request OTP code for login or registration

**Public:** Yes

**Request Body:**
```json
{
  "identifier": "doctor@example.com",
  "channel": "email",
  "purpose": "login",
  "email": "doctor@example.com",
  "phoneNumber": "+966501234567"
}
```

**Parameters:**
- `identifier` (string, required): Email or phone number
- `channel` (string, required): `email` or `whatsapp`
- `purpose` (string, required): `login` or `register`
- `email` (string, optional): Required for registration
- `phoneNumber` (string, optional): Required for registration

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Verification code sent via email",
  "data": {
    "channel": "email",
    "expiresIn": 300,
    "maskedIdentifier": "do***@example.com"
  }
}
```

**Error Responses:**
- `404` - User not found (for login)
- `409` - User already exists (for registration)
- `429` - Rate limit exceeded
- `503` - Service not configured

---

### 2. Verify OTP

**Endpoint:** `POST /auth/verify-otp`

**Description:** Verify OTP code and complete login/registration

**Public:** Yes

**Request Body (Login):**
```json
{
  "identifier": "doctor@example.com",
  "code": "123456",
  "channel": "email",
  "purpose": "login"
}
```

**Request Body (Registration):**
```json
{
  "identifier": "doctor@example.com",
  "code": "123456",
  "channel": "email",
  "purpose": "register",
  "name": "Dr. Ahmed Hassan",
  "email": "doctor@example.com",
  "phoneNumber": "+966501234567",
  "specialty": "IMPLANTOLOGY",
  "clinicName": "Riyadh Dental Center"
}
```

**Registration Parameters:**
- `name` (string, required): Full name
- `email` (string, required): Email address
- `phoneNumber` (string, required): Phone number in E.164 format
- `specialty` (string, optional): One of: `GENERAL_DENTISTRY`, `ORTHODONTICS`, `PERIODONTICS`, `ENDODONTICS`, `PROSTHODONTICS`, `ORAL_SURGERY`, `PEDIATRIC_DENTISTRY`, `COSMETIC_DENTISTRY`, `IMPLANTOLOGY`, `ORAL_PATHOLOGY`, `OTHER`
- `specialtyOther` (string, optional): Required if specialty is `OTHER`
- `clinicName` (string, optional): Clinic name

**Response:** `200 OK` (Login) / `201 Created` (Registration)
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": {
      "id": 1,
      "email": "doctor@example.com",
      "role": "client",
      "emailVerified": true,
      "phoneVerified": false,
      "profile": {
        "id": 1,
        "name": "Dr. Ahmed Hassan",
        "clientType": "doctor",
        "specialty": "IMPLANTOLOGY",
        "clinicName": "Riyadh Dental Center"
      }
    },
    "accessToken": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

---

### 3. Logout

**Endpoint:** `POST /auth/logout`

**Description:** Logout and blacklist current token

**Authentication:** Required

**Request Body:** None

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Logged out successfully"
}
```

---

## Profile Management

### 1. Get Profile

**Endpoint:** `GET /profile`

**Description:** Get current user profile

**Authentication:** Required (Client only)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "profile": {
      "id": 1,
      "clientType": "doctor",
      "name": "Dr. Ahmed Hassan",
      "specialty": "IMPLANTOLOGY",
      "clinicName": "Riyadh Dental Center",
      "createdAt": "2024-01-01T00:00:00.000Z",
      "updatedAt": "2024-01-01T00:00:00.000Z"
    },
    "user": {
      "id": 1,
      "email": "doctor@example.com",
      "phoneNumber": "+966501234567",
      "emailVerified": true,
      "phoneVerified": true,
      "accountStatus": "active",
      "createdAt": "2024-01-01T00:00:00.000Z",
      "lastLoginAt": "2024-01-15T10:30:00.000Z"
    },
    "addresses": [
      {
        "id": 1,
        "label": "Clinic",
        "country": "Saudi Arabia",
        "city": "Riyadh",
        "district": "Olaya",
        "street": "King Fahd Road",
        "building": "Building 123",
        "postalCode": "12345",
        "isDefault": true
      }
    ]
  }
}
```

---

### 2. Update Profile

**Endpoint:** `PUT /profile`

**Description:** Update profile information

**Authentication:** Required (Client only)

**Request Body:**
```json
{
  "name": "Dr. Ahmed Hassan Al-Mansour",
  "specialty": "PROSTHODONTICS",
  "clinicName": "New Clinic Name"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Profile updated successfully",
  "data": {
    "profile": {
      "id": 1,
      "name": "Dr. Ahmed Hassan Al-Mansour",
      "specialty": "PROSTHODONTICS",
      "clinicName": "New Clinic Name"
    }
  }
}
```

---

## Address Management

### 1. List Addresses

**Endpoint:** `GET /profile/addresses`

**Authentication:** Required (Client only)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "addresses": [
      {
        "id": 1,
        "label": "Main Clinic",
        "country": "Saudi Arabia",
        "city": "Riyadh",
        "district": "Olaya",
        "street": "King Fahd Road",
        "building": "Building 123",
        "postalCode": "12345",
        "isDefault": true,
        "createdAt": "2024-01-01T00:00:00.000Z"
      }
    ]
  }
}
```

---

### 2. Add Address

**Endpoint:** `POST /profile/addresses`

**Authentication:** Required (Client only)

**Note:** Maximum 5 addresses per user

**Request Body:**
```json
{
  "label": "Home",
  "country": "Saudi Arabia",
  "city": "Riyadh",
  "district": "Al Malqa",
  "street": "Northern Ring Road",
  "building": "Villa 456",
  "postalCode": "11564",
  "latitude": 24.7136,
  "longitude": 46.6753,
  "isDefault": false
}
```

**Required Fields:**
- `city` (string)
- `street` (string)

**Response:** `201 Created`
```json
{
  "success": true,
  "message": "Address added successfully",
  "data": {
    "address": {
      "id": 2,
      "label": "Home",
      "city": "Riyadh",
      "isDefault": false
    }
  }
}
```

---

### 3. Update Address

**Endpoint:** `PUT /profile/addresses/:id`

**Authentication:** Required (Client only)

**Request Body:**
```json
{
  "label": "Updated Label",
  "isDefault": true
}
```

**Response:** `200 OK`

---

### 4. Delete Address

**Endpoint:** `DELETE /profile/addresses/:id`

**Authentication:** Required (Client only)

**Response:** `200 OK`

---

### 5. Set Default Address

**Endpoint:** `PUT /profile/addresses/:id/default`

**Authentication:** Required (Client only)

**Response:** `200 OK`

---

## Contact Change (3-Step Process)

### Step 1: Request Contact Change

**Endpoint:** `POST /profile/contact/request`

**Description:** Send OTP to OLD contact

**Request Body:**
```json
{
  "contactType": "email",
  "newContact": "newemail@example.com"
}
```

**Parameters:**
- `contactType` (string): `email` or `phone`
- `newContact` (string): New email or phone number

**Response:** `200 OK`

---

### Step 2: Verify Old Contact

**Endpoint:** `POST /profile/contact/verify-old`

**Description:** Verify OTP from old contact, send OTP to new contact

**Request Body:**
```json
{
  "contactType": "email",
  "code": "123456",
  "newContact": "newemail@example.com"
}
```

**Response:** `200 OK`

---

### Step 3: Verify New Contact

**Endpoint:** `POST /profile/contact/verify-new`

**Description:** Verify OTP from new contact and complete change

**Request Body:**
```json
{
  "contactType": "email",
  "code": "654321",
  "newContact": "newemail@example.com"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Email updated successfully",
  "data": {
    "email": "newemail@example.com"
  }
}
```

---

## Case Management

### 1. Create Case

**Endpoint:** `POST /cases`

**Description:** Create a new case (draft or submit)

**Authentication:** Required (Client only)

**Request Body:**
```json
{
  "patientName": "Ahmed Mohammed",
  "patientAge": 45,
  "patientGender": "male",
  "procedureCategory": "single_implant",
  "guideType": "tooth_support",
  "requiredService": "full_solution",
  "implantSystem": "straumann",
  "teethNumbers": [14, 15],
  "clinicalNotes": "Good bone density",
  "specialInstructions": "Patient prefers morning appointments",
  "isDraft": true
}
```

**Parameters:**
- `patientName` (string, optional)
- `patientAge` (number, optional)
- `patientGender` (string, optional): `male`, `female`, `other`
- `procedureCategory` (string, required for submit): `single_implant`, `multiple_implant`, `full_arch`, `gbr`, `other`
- `guideType` (string, required for submit): `tooth_support`, `tissue_support`, `bone_support`, `stackable`, `hybrid`, `other`
- `requiredService` (string, required for submit): `study_only`, `full_solution`
- `implantSystem` (string, optional): `nobel_biocare`, `straumann`, `zimmer_biomet`, `osstem`, etc.
- `teethNumbers` (array, optional): Array of tooth numbers
- `clinicalNotes` (string, optional)
- `specialInstructions` (string, optional)
- `isDraft` (boolean, optional): Default `true`, set `false` to submit

**Response:** `201 Created`
```json
{
  "success": true,
  "message": "Case saved as draft",
  "data": {
    "case": {
      "id": 1,
      "caseNumber": "CASE-1234567890-123",
      "status": "draft",
      "isDraft": true,
      "patientName": "Ahmed Mohammed",
      "procedureCategory": "single_implant"
    }
  }
}
```

---

### 2. List Cases

**Endpoint:** `GET /cases`

**Description:** List user's cases with filters

**Authentication:** Required (Client only)

**Query Parameters:**
- `status` (string, optional): Filter by status
- `isDraft` (boolean, optional): Filter drafts
- `procedureCategory` (string, optional)
- `page` (number, optional): Default 1
- `limit` (number, optional): Default 10
- `sortBy` (string, optional): Default `createdAt`
- `sortOrder` (string, optional): `asc` or `desc`

**Example:** `GET /cases?status=submitted&page=1&limit=10`

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "cases": [
      {
        "id": 1,
        "caseNumber": "CASE-1234567890-123",
        "status": "submitted",
        "isDraft": false,
        "patientName": "Ahmed Mohammed",
        "procedureCategory": "single_implant",
        "createdAt": "2024-01-01T00:00:00.000Z",
        "_count": {
          "files": 3,
          "comments": 2,
          "quotes": 1
        }
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 10,
      "total": 25,
      "totalPages": 3
    }
  }
}
```

---

### 3. Get Case Details

**Endpoint:** `GET /cases/:id`

**Description:** Get full case details with files, comments, quotes

**Authentication:** Required

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "case": {
      "id": 1,
      "caseNumber": "CASE-1234567890-123",
      "status": "submitted",
      "patientName": "Ahmed Mohammed",
      "files": [...],
      "comments": [...],
      "quotes": [...],
      "payments": [...],
      "statusHistory": [...]
    }
  }
}
```

---

### 4. Update Case (Draft Only)

**Endpoint:** `PUT /cases/:id`

**Description:** Update draft case

**Authentication:** Required (Client only)

**Note:** Only draft cases can be updated

**Request Body:**
```json
{
  "patientName": "Updated Name",
  "clinicalNotes": "Updated notes"
}
```

**Response:** `200 OK`

**Error:** `400` - Only draft cases can be updated

---

### 5. Submit Draft Case

**Endpoint:** `POST /cases/:id/submit`

**Description:** Submit draft case for processing

**Authentication:** Required (Client only)

**Note:** Case must have all required fields filled

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Case submitted successfully",
  "data": {
    "case": {
      "id": 1,
      "status": "submitted",
      "isDraft": false
    }
  }
}
```

---

## Comments

### 1. List Comments

**Endpoint:** `GET /comments/cases/:id/comments`

**Description:** Get all comments for a case

**Authentication:** Required

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "comments": [
      {
        "id": 1,
        "comment": "Please check the CBCT scan",
        "authorType": "client",
        "isRead": false,
        "createdAt": "2024-01-01T00:00:00.000Z",
        "clientProfile": {
          "id": 1,
          "name": "Dr. Ahmed Hassan"
        }
      }
    ],
    "total": 5
  }
}
```

---

### 2. Add Comment

**Endpoint:** `POST /comments/cases/:id/comments`

**Description:** Add comment to case

**Authentication:** Required

**Request Body:**
```json
{
  "comment": "Please review the latest files I uploaded"
}
```

**Note:** Comments cannot be edited or deleted after posting

**Response:** `201 Created`

---

### 3. Mark Comment as Read

**Endpoint:** `PUT /comments/:id/read`

**Description:** Mark single comment as read

**Authentication:** Required

**Response:** `200 OK`

---

### 4. Mark All Comments as Read

**Endpoint:** `PUT /comments/cases/:id/read-all`

**Description:** Mark all unread comments in a case as read

**Authentication:** Required

**Response:** `200 OK`

---

## File Management

### 1. Upload File

**Endpoint:** `POST /files/cases/:id/files`

**Description:** Upload file to case

**Authentication:** Required

**Request Body:**
```json
{
  "fileName": "cbct_scan.dcm",
  "fileUrl": "https://s3.amazonaws.com/bucket/file.dcm",
  "fileType": "application/dicom",
  "fileSize": 52428800,
  "category": "cbct",
  "description": "Full mouth CBCT scan"
}
```

**Parameters:**
- `fileName` (string, required)
- `fileUrl` (string, required): URL where file is stored
- `fileType` (string, required): MIME type
- `fileSize` (number, required): Size in bytes (max 100MB)
- `category` (string, optional): `xray`, `ct_scan`, `cbct`, `dicom`, `intraoral_scan`, `stl`, `clinical_photo`, `prescription`, `study_file`, `design_file`, `production_file`, `other`
- `description` (string, optional)

**Response:** `201 Created`

---

### 2. List Files

**Endpoint:** `GET /files/cases/:id/files`

**Description:** List all files for a case

**Authentication:** Required

**Query Parameters:**
- `category` (string, optional): Filter by category

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "files": [
      {
        "id": 1,
        "fileName": "cbct_scan.dcm",
        "fileUrl": "https://...",
        "fileSize": 52428800,
        "category": "cbct",
        "uploadedBy": "client",
        "createdAt": "2024-01-01T00:00:00.000Z"
      }
    ],
    "total": 3
  }
}
```

---

### 3. Delete File

**Endpoint:** `DELETE /files/:id`

**Description:** Delete own file

**Authentication:** Required

**Note:** Users can only delete their own files

**Response:** `200 OK`

---

## Quotes

### 1. List Quotes for Case

**Endpoint:** `GET /quotes/cases/:id/quotes`

**Description:** Get all quotes for a case

**Authentication:** Required

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "quotes": [
      {
        "id": 1,
        "quoteNumber": "QUOTE-1234567890-123",
        "studyFee": 100,
        "designFee": 500,
        "productionFee": 2000,
        "deliveryFee": 100,
        "subtotal": 2700,
        "vatRate": 15,
        "vatAmount": 405,
        "totalAmount": 3105,
        "isAccepted": false,
        "isRejected": false,
        "validUntil": "2024-02-01T00:00:00.000Z",
        "createdAt": "2024-01-01T00:00:00.000Z"
      }
    ],
    "total": 1
  }
}
```

---

### 2. Get Quote Details

**Endpoint:** `GET /quotes/:id`

**Description:** Get single quote with details

**Authentication:** Required

**Response:** `200 OK`

---

### 3. Accept Quote

**Endpoint:** `PUT /quotes/:id/accept`

**Description:** Accept quote (Doctor only)

**Authentication:** Required (Client only)

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Quote accepted successfully. Please proceed with production payment"
}
```

**Error Responses:**
- `400` - Quote already accepted/rejected/expired

---

### 4. Reject Quote

**Endpoint:** `PUT /quotes/:id/reject`

**Description:** Reject quote with reason (Doctor only)

**Authentication:** Required (Client only)

**Request Body:**
```json
{
  "rejectionReason": "Price is too high, please revise",
  "requestRevision": true
}
```

**Parameters:**
- `rejectionReason` (string, required): Free text reason
- `requestRevision` (boolean, optional): `true` to request revision, `false` to cancel case. Default `true`

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Quote rejected. Admin will send a revised quote"
}
```

---

## Payments

### 1. Upload Study Payment Proof

**Endpoint:** `POST /payments/study-fee`

**Description:** Upload study fee payment proof (SAR 100)

**Authentication:** Required (Client only)

**Request Body:**
```json
{
  "caseId": 1,
  "amount": 100,
  "paymentMethod": "bank_transfer",
  "proofUrl": "https://example.com/payment-proof.jpg",
  "transactionId": "TXN123456",
  "transactionDate": "2024-01-15T10:00:00.000Z",
  "notes": "Transferred from Al Rajhi Bank"
}
```

**Parameters:**
- `caseId` (number, required)
- `amount` (number, required): Must be 100
- `paymentMethod` (string, required): `bank_transfer`, `cash`
- `proofUrl` (string, required): URL to payment proof image
- `transactionId` (string, optional)
- `transactionDate` (string, optional): ISO date
- `notes` (string, optional)

**Response:** `201 Created`
```json
{
  "success": true,
  "message": "Study payment proof uploaded successfully. Awaiting admin verification",
  "data": {
    "payment": {
      "id": 1,
      "paymentNumber": "PAY-1234567890-123",
      "paymentType": "study_fee",
      "amount": 100,
      "status": "pending"
    }
  }
}
```

---

### 2. Upload Production Payment Proof

**Endpoint:** `POST /payments/production-fee`

**Description:** Upload production fee payment proof

**Authentication:** Required (Client only)

**Request Body:**
```json
{
  "caseId": 1,
  "quoteId": 1,
  "amount": 3105,
  "paymentMethod": "bank_transfer",
  "proofUrl": "https://example.com/payment-proof.jpg",
  "transactionId": "TXN789012",
  "transactionDate": "2024-01-20T14:30:00.000Z",
  "notes": "Full payment for production"
}
```

**Response:** `201 Created`

---

### 3. List Payments

**Endpoint:** `GET /payments`

**Description:** List all payments

**Authentication:** Required

**Query Parameters:**
- `caseId` (number, optional)
- `status` (string, optional): `pending`, `verified`, `failed`
- `paymentType` (string, optional): `study_fee`, `production_fee`
- `page` (number, optional)
- `limit` (number, optional)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "payments": [...],
    "pagination": {...}
  }
}
```

---

### 4. Get Payment Details

**Endpoint:** `GET /payments/:id`

**Authentication:** Required

**Response:** `200 OK`

---

### 5. Request Refund

**Endpoint:** `POST /payments/:id/refund-request`

**Description:** Request refund for production payment

**Authentication:** Required (Client only)

**Note:** Study fee is non-refundable

**Request Body:**
```json
{
  "refundReason": "Need to cancel case due to patient circumstances"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Refund request submitted successfully. Awaiting admin review"
}
```

---

## Designer Endpoints

**Note:** All designer endpoints require `role: "designer"`

### 1. List All Cases

**Endpoint:** `GET /designer/cases`

**Description:** List all submitted cases (no drafts)

**Authentication:** Required (Designer only)

**Query Parameters:**
- `status` (string, optional)
- `clientProfileId` (number, optional)
- `procedureCategory` (string, optional)
- `page` (number, optional)
- `limit` (number, optional)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "cases": [
      {
        "id": 1,
        "caseNumber": "CASE-1234567890-123",
        "status": "submitted",
        "clientProfile": {
          "id": 1,
          "name": "Dr. Ahmed Hassan",
          "specialty": "IMPLANTOLOGY",
          "clinicName": "Riyadh Dental Center"
        }
      }
    ],
    "pagination": {...}
  }
}
```

**Note:** Designer cannot see client email or phone

---

### 2. Get Case Details (Designer)

**Endpoint:** `GET /designer/cases/:id`

**Authentication:** Required (Designer only)

**Response:** Similar to client case details but without email/phone

---

### 3. Update Case Status

**Endpoint:** `PUT /designer/cases/:id/status`

**Description:** Change case status through workflow

**Authentication:** Required (Designer only)

**Request Body:**
```json
{
  "status": "study_in_progress",
  "notes": "Started working on the case"
}
```

**Valid Transitions:**
- `submitted` → `study_in_progress`
- `study_in_progress` → `study_completed`
- `in_production` → `production_completed`
- `production_completed` → `ready_for_pickup` OR `out_for_delivery`
- `ready_for_pickup` → `delivered`
- `out_for_delivery` → `delivered`

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Case status updated to study_in_progress"
}
```

**Error:** `400` - Invalid status transition

---

### 4. Get Available Statuses

**Endpoint:** `GET /designer/cases/:id/available-statuses`

**Description:** Get next possible statuses for a case

**Authentication:** Required (Designer only)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "currentStatus": "submitted",
    "availableStatuses": ["study_in_progress"]
  }
}
```

---

### 5. List Clients

**Endpoint:** `GET /designer/clients`

**Description:** List all clients

**Authentication:** Required (Designer only)

**Query Parameters:**
- `clientType` (string, optional): `doctor` or `lab`
- `specialty` (string, optional)
- `page` (number, optional)
- `limit` (number, optional)

**Response:** `200 OK`

**Note:** Email and phone visible only to admins

---

### 6. View Client Profile

**Endpoint:** `GET /designer/clients/:id`

**Description:** View client profile

**Authentication:** Required (Designer only)

**Response:** `200 OK`
```json
{
  "success": true,
  "data": {
    "profile": {
      "id": 1,
      "name": "Dr. Ahmed Hassan",
      "specialty": "IMPLANTOLOGY",
      "clinicName": "Riyadh Dental Center"
    },
    "user": {
      "id": 1,
      "accountStatus": "active",
      "createdAt": "2024-01-01T00:00:00.000Z"
    },
    "casesCount": 15
  }
}
```

**Note:** 
- Regular designers: Cannot see email, phone, addresses
- Admins: Can see all information

---

## Admin Endpoints

**Note:** All admin endpoints require `role: "designer"` AND `isAdmin: true`

### 1. Create Quote

**Endpoint:** `POST /admin/quotes`

**Description:** Create quote for a case

**Authentication:** Required (Admin only)

**Request Body:**
```json
{
  "caseId": 1,
  "studyFee": 100,
  "designFee": 500,
  "productionFee": 2000,
  "deliveryFee": 100,
  "discountAmount": 0,
  "discountReason": "",
  "vatRate": 15,
  "notes": "Quote valid for 30 days",
  "internalNotes": "Standard pricing",
  "validUntil": "2024-02-01T00:00:00.000Z"
}
```

**Parameters:**
- `caseId` (number, required)
- `studyFee` (number, optional): Default 100
- `designFee` (number, optional): Default 0
- `productionFee` (number, optional): Default 0
- `deliveryFee` (number, optional): Default 0
- `discountAmount` (number, optional): Default 0
- `discountReason` (string, optional)
- `vatRate` (number, optional): Default 15
- `notes` (string, optional): Visible to client
- `internalNotes` (string, optional): Admin only
- `validUntil` (string, optional): ISO date, default 30 days

**Response:** `201 Created`

---

### 2. Revise Quote

**Endpoint:** `PUT /admin/quotes/:id`

**Description:** Revise rejected quote

**Authentication:** Required (Admin only)

**Request Body:** Same as create quote

**Response:** `200 OK`

---

### 3. Verify Payment

**Endpoint:** `PUT /admin/payments/:id/verify`

**Description:** Verify payment proof

**Authentication:** Required (Admin only)

**Request Body:**
```json
{
  "verificationNotes": "Payment verified from bank statement"
}
```

**Response:** `200 OK`
```json
{
  "success": true,
  "message": "Payment verified successfully"
}
```

**Side Effects:**
- Study fee verification → Case status: `pending_study_payment` → `submitted`
- Production fee verification → Case status: `pending_production_payment` → `in_production`

---

### 4. Reject Payment

**Endpoint:** `PUT /admin/payments/:id/reject`

**Description:** Reject payment proof

**Authentication:** Required (Admin only)

**Request Body:**
```json
{
  "rejectionReason": "Payment proof is unclear, please upload clearer image"
}
```

**Response:** `200 OK`

---

### 5. Approve Refund

**Endpoint:** `PUT /admin/payments/:id/approve-refund`

**Description:** Approve refund request with partial amount

**Authentication:** Required (Admin only)

**Request Body:**
```json
{
  "refundAmount": 1500,
  "refundNotes": "Partial refund approved. Study already completed."
}
```

**Parameters:**
- `refundAmount` (number, required): Amount to refund (can be partial)
- `refundNotes` (string, optional): Reason for partial/full refund

**Response:** `200 OK`

---

### 6. Reject Refund

**Endpoint:** `PUT /admin/payments/:id/reject-refund`

**Description:** Reject refund request

**Authentication:** Required (Admin only)

**Request Body:**
```json
{
  "rejectionReason": "Case is already in production, cannot cancel"
}
```

**Response:** `200 OK`

---

## Error Codes

### HTTP Status Codes

- `200` - Success
- `201` - Created
- `400` - Bad Request (validation error)
- `401` - Unauthorized (missing/invalid token)
- `403` - Forbidden (insufficient permissions)
- `404` - Not Found
- `409` - Conflict (duplicate resource)
- `429` - Too Many Requests (rate limit)
- `500` - Internal Server Error
- `503` - Service Unavailable

### Error Response Format

```json
{
  "success": false,
  "message": "Error description",
  "errors": ["Error 1", "Error 2"]
}
```

---

## Case Status Flow

```
draft → pending_study_payment → submitted → study_in_progress → 
study_completed → quote_sent → quote_accepted → 
pending_production_payment → in_production → production_completed → 
ready_for_pickup/out_for_delivery → delivered → completed
```

**Special Statuses:**
- `cancelled` - Quote expired or rejected without revision
- `quote_rejected` - Quote rejected, waiting for revision
- `refund_requested` - Doctor requested refund
- `refunded` - Refund approved and processed

---

## Authentication Flow

```
1. Doctor → POST /auth/request-otp (purpose: register)
2. Doctor → POST /auth/verify-otp (with registration data)
3. Doctor → Receives accessToken
4. Doctor → Uses token in Authorization header for all requests
5. Doctor → POST /auth/logout (when done)
```

---

## Study Payment Flow

```
1. Doctor creates case as draft
2. Doctor uploads study payment proof → POST /payments/study-fee
3. Case status → pending_study_payment
4. Admin verifies payment → PUT /admin/payments/:id/verify
5. Case status → submitted (now visible to designers)
```

---

## Quote & Production Flow

```
1. Designer changes status to study_in_progress
2. Designer completes study → study_completed
3. Admin creates quote → POST /admin/quotes
4. Case status → quote_sent (30-day validity)
5. Doctor accepts → PUT /quotes/:id/accept
6. Doctor uploads production payment → POST /payments/production-fee
7. Admin verifies payment → Case status → in_production
8. Designer completes production → production_completed
9. Designer delivers → delivered
```

---

**End of Documentation**
