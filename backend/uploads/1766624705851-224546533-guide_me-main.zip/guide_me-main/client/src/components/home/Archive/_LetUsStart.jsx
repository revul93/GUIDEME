import React, { useState } from "react";
import { useTranslation } from "react-i18next";
import AuthModal from "../layout/AuthModal.jsx";

const LetUsStart = () => {
  const { t } = useTranslation();
  const [authModalOpen, setAuthModalOpen] = useState(false);

  const handleScrollTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleGetStarted = () => {
    setAuthModalOpen(true);
  };

  const handleAuthSuccess = () => {
    setAuthModalOpen(false);
    // Redirect to dashboard or show success message
    window.location.href = "/dashboard";
  };

  return (
    <>
      <section
        id="let-us-start"
        className="relative min-h-screen flex flex-col items-center justify-center py-16 scroll-mt-20 bg-gradient-to-br from-primary/10 via-secondary/10 to-primary/5 dark:from-primary/20 dark:via-secondary/20 dark:to-primary/10"
      >
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col justify-center">
          {/* Main Content */}
          <div className="text-center max-w-3xl mx-auto mb-12">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              {t("letUsStart.title")}
            </h2>
            <p className="text-base sm:text-lg text-gray-600 dark:text-gray-300 mb-8">
              {t("letUsStart.subtitle")}
            </p>

            {/* CTA Button */}
            <button
              onClick={handleGetStarted}
              className="inline-flex items-center gap-3 px-10 py-5 bg-primary hover:bg-primary-dark dark:bg-secondary dark:hover:bg-secondary-dark text-white text-lg font-bold rounded-full shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 cursor-pointer"
            >
              <span>{t("letUsStart.cta")}</span>
              <svg
                className="w-6 h-6 rtl:rotate-180"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M13 7l5 5m0 0l-5 5m5-5H6"
                />
              </svg>
            </button>
          </div>

          {/* Features Grid */}
          <div className="grid sm:grid-cols-3 gap-6 max-w-4xl mx-auto mb-12">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-primary/20 dark:bg-secondary/20 flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-primary dark:text-secondary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z"
                  />
                </svg>
              </div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white mb-2">
                {t("letUsStart.features.fast.title")}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {t("letUsStart.features.fast.description")}
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-primary/20 dark:bg-secondary/20 flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-primary dark:text-secondary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                  />
                </svg>
              </div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white mb-2">
                {t("letUsStart.features.secure.title")}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {t("letUsStart.features.secure.description")}
              </p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 mx-auto mb-3 rounded-full bg-primary/20 dark:bg-secondary/20 flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-primary dark:text-secondary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z"
                  />
                </svg>
              </div>
              <h3 className="text-base font-bold text-gray-900 dark:text-white mb-2">
                {t("letUsStart.features.support.title")}
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {t("letUsStart.features.support.description")}
              </p>
            </div>
          </div>
        </div>

        {/* Scroll to Top Button */}
        <button
          onClick={handleScrollTop}
          className="mb-8 flex flex-col items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-secondary transition-colors cursor-pointer group"
        >
          <span className="text-sm font-medium">{t("common.backToTop")}</span>
          <svg
            className="w-6 h-6 animate-bounce group-hover:text-primary dark:group-hover:text-secondary rotate-180"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 14l-7 7m0 0l-7-7m7 7V3"
            />
          </svg>
        </button>
      </section>

      {/* Auth Modal */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialType="register"
        onSuccess={handleAuthSuccess}
      />
    </>
  );
};

export default LetUsStart;
