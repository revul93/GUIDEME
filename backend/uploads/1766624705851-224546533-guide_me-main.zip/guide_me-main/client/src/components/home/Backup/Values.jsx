import { useTranslation } from "react-i18next";
import FavoriteIcon from "@mui/icons-material/Favorite";
import EmojiObjectsIcon from "@mui/icons-material/EmojiObjects";
import GroupsIcon from "@mui/icons-material/Groups";
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome";

const Values = () => {
  const { t } = useTranslation();

  return (
    <section
      id="values"
      className="py-20 bg-gray-50 dark:bg-gray-800 scroll-mt-20"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            {t("values.title")}
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            {t("values.subtitle")}
          </p>
        </div>

        {/* Mission & Vision */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Mission */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 dark:bg-primary/20 rounded-full mb-6">
              <span className="text-3xl">🎯</span>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              {t("values.mission.title")}
            </h3>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              {t("values.mission.description")}
            </p>
          </div>

          {/* Vision */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-secondary/10 dark:bg-secondary/20 rounded-full mb-6">
              <span className="text-3xl">🚀</span>
            </div>
            <h3 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              {t("values.vision.title")}
            </h3>
            <p className="text-gray-700 dark:text-gray-300 leading-relaxed">
              {t("values.vision.description")}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Values;
