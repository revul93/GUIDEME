import React from "react";
import { useTranslation } from "react-i18next";
import { useLanguage } from "../../context/LanguageContext.jsx";

const Team = () => {
  const { t } = useTranslation();
  const { language } = useLanguage();

  const handleScrollNext = () => {
    const element = document.getElementById("let-us-start");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const teamMembers = [
    {
      name: t("team.members.member1.name"),
      role: t("team.members.member1.role"),
      gradient: "from-orange-400 to-rose-400",
    },
    {
      name: t("team.members.member2.name"),
      role: t("team.members.member2.role"),
      gradient: "from-amber-400 to-orange-400",
    },
    {
      name: t("team.members.member3.name"),
      role: t("team.members.member3.role"),
      gradient: "from-yellow-400 to-amber-400",
    },
    {
      name: t("team.members.member4.name"),
      role: t("team.members.member4.role"),
      gradient: "from-red-400 to-orange-400",
    },
  ];

  // Generate initials from name
  const getInitials = (name) => {
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <section
      id="team"
      className="relative min-h-screen flex flex-col items-center justify-center py-16 scroll-mt-20 bg-gradient-to-br from-orange-50 via-amber-50/40 to-yellow-50/40 dark:from-gray-900 dark:via-orange-900/10 dark:to-amber-900/10"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col justify-center">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-3">
            {t("team.title")}
          </h2>
          <p className="text-base text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            {t("team.subtitle")}
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {teamMembers.map((member, index) => (
            <div
              key={index}
              className="group bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 text-center"
            >
              {/* Avatar with Online Indicator */}
              <div className="relative inline-block mb-4">
                <div
                  className={`w-24 h-24 rounded-full bg-gradient-to-br ${member.gradient} flex items-center justify-center shadow-lg group-hover:shadow-xl transition-shadow`}
                >
                  <span className="text-2xl font-bold text-white">
                    {getInitials(member.name)}
                  </span>
                </div>
                {/* Online indicator */}
                <div className="absolute bottom-0 right-0 rtl:right-auto rtl:left-0 w-6 h-6 bg-green-500 border-4 border-white dark:border-gray-800 rounded-full"></div>
              </div>

              {/* Info */}
              <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-1">
                {member.name}
              </h3>
              <p className="text-sm text-primary dark:text-secondary font-medium mb-4">
                {member.role}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll Button */}
      <button
        onClick={handleScrollNext}
        className="mb-8 flex flex-col items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-secondary transition-colors cursor-pointer group"
      >
        <span className="text-sm font-medium">{t("common.next")}</span>
        <svg
          className="w-6 h-6 animate-bounce group-hover:text-primary dark:group-hover:text-secondary"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </button>
    </section>
  );
};

export default Team;
