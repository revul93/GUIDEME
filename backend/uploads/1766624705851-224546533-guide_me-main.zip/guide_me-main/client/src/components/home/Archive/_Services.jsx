import React from "react";
import { useTranslation } from "react-i18next";
import PrecisionManufacturingIcon from "@mui/icons-material/PrecisionManufacturing";
import DesignServicesIcon from "@mui/icons-material/DesignServices";
import ScienceIcon from "@mui/icons-material/Science";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";

const Services = () => {
  const { t } = useTranslation();

  const handleScrollNext = () => {
    const element = document.getElementById("portfolio");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const services = [
    {
      icon: PrecisionManufacturingIcon,
      title: t("services.surgical.title"),
      description: t("services.surgical.description"),
      gradient: "from-blue-500 to-cyan-500",
      bgColor: "bg-blue-50 dark:bg-blue-900/10",
    },
    {
      icon: DesignServicesIcon,
      title: t("services.prosthetics.title"),
      description: t("services.prosthetics.description"),
      gradient: "from-purple-500 to-pink-500",
      bgColor: "bg-purple-50 dark:bg-purple-900/10",
    },
    {
      icon: ScienceIcon,
      title: t("services.planning.title"),
      description: t("services.planning.description"),
      gradient: "from-green-500 to-emerald-500",
      bgColor: "bg-green-50 dark:bg-green-900/10",
    },
    {
      icon: LocalShippingIcon,
      title: t("services.delivery.title"),
      description: t("services.delivery.description"),
      gradient: "from-orange-500 to-red-500",
      bgColor: "bg-orange-50 dark:bg-orange-900/10",
    },
  ];

  return (
    <section
      id="services"
      className="relative min-h-screen flex flex-col items-center justify-center py-16 scroll-mt-20 bg-gradient-to-br from-gray-50 via-blue-50/30 to-purple-50/30 dark:from-gray-900 dark:via-blue-900/10 dark:to-purple-900/10"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col justify-center">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-3">
            {t("services.title")}
          </h2>
          <p className="text-base text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            {t("services.subtitle")}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className={`${service.bgColor} rounded-2xl p-6 hover:shadow-xl transition-all duration-300 hover:-translate-y-2`}
              >
                <div
                  className={`w-14 h-14 rounded-xl bg-gradient-to-br ${service.gradient} flex items-center justify-center mb-4 shadow-lg`}
                >
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2">
                  {service.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                  {service.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Scroll Button */}
      <button
        onClick={handleScrollNext}
        className="mb-8 flex flex-col items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-secondary transition-colors cursor-pointer group"
      >
        <span className="text-sm font-medium">{t("common.next")}</span>
        <svg
          className="w-6 h-6 animate-bounce group-hover:text-primary dark:group-hover:text-secondary"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </button>
    </section>
  );
};

export default Services;
