import React from "react";
import { useTranslation } from "react-i18next";

const Portfolio = () => {
  const { t } = useTranslation();

  const handleScrollNext = () => {
    const element = document.getElementById("values");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const portfolioItems = [
    {
      title: t("portfolio.items.item1.title"),
      category: t("portfolio.items.item1.category"),
      gradient: "from-teal-500 to-cyan-500",
    },
    {
      title: t("portfolio.items.item2.title"),
      category: t("portfolio.items.item2.category"),
      gradient: "from-blue-500 to-indigo-500",
    },
    {
      title: t("portfolio.items.item3.title"),
      category: t("portfolio.items.item3.category"),
      gradient: "from-purple-500 to-pink-500",
    },
    {
      title: t("portfolio.items.item4.title"),
      category: t("portfolio.items.item4.category"),
      gradient: "from-green-500 to-teal-500",
    },
    {
      title: t("portfolio.items.item5.title"),
      category: t("portfolio.items.item5.category"),
      gradient: "from-orange-500 to-amber-500",
    },
    {
      title: t("portfolio.items.item6.title"),
      category: t("portfolio.items.item6.category"),
      gradient: "from-rose-500 to-red-500",
    },
  ];

  return (
    <section
      id="portfolio"
      className="relative min-h-screen flex flex-col items-center justify-center py-16 scroll-mt-20 bg-gradient-to-br from-green-50 via-teal-50/40 to-cyan-50/40 dark:from-gray-900 dark:via-green-900/10 dark:to-teal-900/10"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col justify-center">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-3">
            {t("portfolio.title")}
          </h2>
          <p className="text-base text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            {t("portfolio.subtitle")}
          </p>
        </div>

        {/* Portfolio Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {portfolioItems.map((item, index) => (
            <div
              key={index}
              className="group relative overflow-hidden rounded-2xl shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2 cursor-pointer"
            >
              {/* Placeholder Image with Gradient */}
              <div
                className={`aspect-[4/3] bg-gradient-to-br ${item.gradient} flex items-center justify-center`}
              >
                <svg
                  className="w-16 h-16 text-white/30"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"
                  />
                </svg>
              </div>

              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-6">
                <div>
                  <p className="text-xs text-white/80 mb-1">{item.category}</p>
                  <h3 className="text-lg font-bold text-white">{item.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll Button */}
      <button
        onClick={handleScrollNext}
        className="mb-8 flex flex-col items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-secondary transition-colors cursor-pointer group"
      >
        <span className="text-sm font-medium">{t("common.next")}</span>
        <svg
          className="w-6 h-6 animate-bounce group-hover:text-primary dark:group-hover:text-secondary"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </button>
    </section>
  );
};

export default Portfolio;
