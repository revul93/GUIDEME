import { useTranslation } from "react-i18next";
import PhoneIcon from "@mui/icons-material/Phone";
import EmailIcon from "@mui/icons-material/Email";
import LocationOnIcon from "@mui/icons-material/LocationOn";

const Contact = () => {
  const { t } = useTranslation();

  const contactInfo = [
    {
      icon: PhoneIcon,
      title: t("contact.phone"),
      value: "+966 54 321 0987",
      href: "tel:+966543210987",
    },
    {
      icon: EmailIcon,
      title: t("contact.email"),
      value: "info@guide-me.pro",
      href: "mailto:info@guide-me.pro",
    },
    {
      icon: LocationOnIcon,
      title: t("contact.location"),
      value: t("contact.address"),
      href: "#",
    },
  ];

  return (
    <section
      id="contact"
      className="py-20 bg-gradient-to-br from-primary to-primary-dark dark:from-gray-900 dark:to-gray-800 scroll-mt-20"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
            {t("contact.title")}
          </h2>
          <p className="text-lg text-white/80">{t("contact.subtitle")}</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Contact Info */}
          <div className="space-y-6">
            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <a
                  key={index}
                  href={info.href}
                  className="flex items-start space-x-4 rtl:space-x-reverse p-6 bg-white/10 backdrop-blur-sm rounded-2xl hover:bg-white/20 transition-all duration-300 group"
                >
                  <div className="flex-shrink-0">
                    <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center group-hover:bg-white/30 transition-colors">
                      <Icon className="w-7 h-7 text-white" />
                    </div>
                  </div>
                  <div>
                    <h3 className="text-white/80 text-sm font-medium mb-1">
                      {info.title}
                    </h3>
                    <p className="text-white text-lg font-semibold">
                      {info.value}
                    </p>
                  </div>
                </a>
              );
            })}
          </div>

          {/* Right: CTA Card */}
          <div className="bg-white dark:bg-gray-900 rounded-2xl p-8 sm:p-12 shadow-2xl">
            <h3 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white mb-4">
              {t("contact.ready")}
            </h3>
            <p className="text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
              {t("contact.description")}
            </p>

            {/* CTA Message */}
            <div className="cursor-pointer bg-secondary/10 dark:bg-secondary/20 rounded-xl p-6 text-center">
              <p className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                {t("contact.getStarted")}
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                {t("contact.registerMessage")}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
