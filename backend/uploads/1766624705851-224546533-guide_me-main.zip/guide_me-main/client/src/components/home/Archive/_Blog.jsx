import React from "react";
import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import { useLanguage } from "../../context/LanguageContext";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import PersonIcon from "@mui/icons-material/Person";

const Blog = () => {
  const { t } = useTranslation();
  const { direction } = useLanguage();

  // Mock blog posts
  const posts = [
    {
      id: 1,
      title: "The Future of Digital Implant Planning",
      excerpt:
        "Discover how advanced CAD/CAM technology is revolutionizing the way we approach implant dentistry and surgical guide design.",
      image:
        "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&h=600&fit=crop",
      author: "Dr. Sarah Johnson",
      date: "2024-03-15",
      readTime: "5 min read",
      category: "Technology",
    },
    {
      id: 2,
      title: "Best Practices for Full-Arch Restorations",
      excerpt:
        "Learn the essential techniques and considerations for successful full-arch implant planning and execution.",
      image:
        "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=800&h=600&fit=crop",
      author: "Dr. Michael Chen",
      date: "2024-03-10",
      readTime: "7 min read",
      category: "Clinical",
    },
    {
      id: 3,
      title: "GBR: Advanced Bone Regeneration Techniques",
      excerpt:
        "Explore the latest advances in guided bone regeneration and how precise surgical guides improve outcomes.",
      image:
        "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=800&h=600&fit=crop",
      author: "Dr. Emily Rodriguez",
      date: "2024-03-05",
      readTime: "6 min read",
      category: "Surgery",
    },
  ];

  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-800">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
            {t("blog.title")}
          </h2>
          <p className="text-lg text-gray-600 dark:text-gray-400">
            {t("blog.subtitle")}
          </p>
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {posts.map((post) => (
            <article
              key={post.id}
              className="group bg-white dark:bg-gray-900 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 hover:-translate-y-2"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                {/* Category Badge */}
                <div className="absolute top-4 left-4 rtl:left-auto rtl:right-4">
                  <span className="px-3 py-1 bg-secondary text-white text-xs font-medium rounded-full">
                    {post.category}
                  </span>
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                {/* Meta */}
                <div className="flex items-center space-x-4 rtl:space-x-reverse text-xs text-gray-600 dark:text-gray-400 mb-3">
                  <div className="flex items-center space-x-1 rtl:space-x-reverse">
                    <PersonIcon className="w-4 h-4" />
                    <span>{post.author}</span>
                  </div>
                  <div className="flex items-center space-x-1 rtl:space-x-reverse">
                    <AccessTimeIcon className="w-4 h-4" />
                    <span>{post.readTime}</span>
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 group-hover:text-primary dark:group-hover:text-secondary transition-colors">
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 leading-relaxed line-clamp-3">
                  {post.excerpt}
                </p>

                {/* Read More */}
                <Link
                  to={`/blog/${post.id}`}
                  className="inline-flex items-center space-x-2 rtl:space-x-reverse text-sm font-medium text-primary dark:text-secondary hover:underline"
                >
                  <span>{t("blog.readMore")}</span>
                  {direction === "rtl" ? (
                    <ArrowBackIcon className="w-4 h-4" />
                  ) : (
                    <ArrowForwardIcon className="w-4 h-4" />
                  )}
                </Link>
              </div>
            </article>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center">
          <Link
            to="/blog"
            className="inline-flex items-center space-x-2 rtl:space-x-reverse px-8 py-3 bg-primary hover:bg-primary-dark text-white rounded-lg font-medium transition-all duration-300 shadow-lg hover:shadow-xl"
          >
            <span>{t("blog.viewAll")}</span>
            {direction === "rtl" ? (
              <ArrowBackIcon className="w-5 h-5" />
            ) : (
              <ArrowForwardIcon className="w-5 h-5" />
            )}
          </Link>
        </div>
      </div>
    </section>
  );
};

export default Blog;
