import React from "react";
import { useTranslation } from "react-i18next";
import VerifiedIcon from "@mui/icons-material/Verified";
import SpeedIcon from "@mui/icons-material/Speed";
import GroupsIcon from "@mui/icons-material/Groups";
import AutoAwesomeIcon from "@mui/icons-material/AutoAwesome";

const Values1 = () => {
  const { t } = useTranslation();

  const handleScrollNext = () => {
    const element = document.getElementById("team");
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const values = [
    {
      icon: VerifiedIcon,
      title: t("values.quality.title"),
      description: t("values.quality.description"),
      gradient: "from-indigo-500 to-purple-500",
    },
    {
      icon: SpeedIcon,
      title: t("values.efficiency.title"),
      description: t("values.efficiency.description"),
      gradient: "from-purple-500 to-pink-500",
    },
    {
      icon: GroupsIcon,
      title: t("values.collaboration.title"),
      description: t("values.collaboration.description"),
      gradient: "from-pink-500 to-rose-500",
    },
    {
      icon: AutoAwesomeIcon,
      title: t("values.innovation.title"),
      description: t("values.innovation.description"),
      gradient: "from-violet-500 to-purple-500",
    },
  ];

  return (
    <section
      id="values"
      className="relative min-h-screen flex flex-col items-center justify-center py-16 scroll-mt-20 bg-gradient-to-br from-purple-50 via-pink-50/40 to-rose-50/40 dark:from-gray-900 dark:via-purple-900/10 dark:to-pink-900/10"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 flex-1 flex flex-col justify-center">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 dark:text-white mb-3">
            {t("values.title")}
          </h2>
          <p className="text-base text-gray-600 dark:text-gray-400 max-w-2xl mx-auto">
            {t("values.subtitle")}
          </p>
        </div>

        {/* Values Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {values.map((value, index) => {
            const Icon = value.icon;
            return (
              <div
                key={index}
                className="group bg-white dark:bg-gray-800 rounded-2xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-500 hover:-translate-y-2 hover:scale-[1.02]"
              >
                {/* Gradient Header */}
                <div
                  className={`h-28 bg-gradient-to-br ${value.gradient} relative overflow-hidden transition-all duration-500 group-hover:h-32`}
                >
                  <div className="absolute inset-0 bg-black/10 group-hover:bg-black/5 transition-colors"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Icon className="w-14 h-14 text-white opacity-90 transform group-hover:scale-110 group-hover:rotate-6 transition-transform duration-500" />
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-lg font-bold text-gray-900 dark:text-white mb-2 group-hover:text-primary dark:group-hover:text-secondary transition-colors">
                    {value.title}
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                    {value.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Scroll Button */}
      <button
        onClick={handleScrollNext}
        className="mb-8 flex flex-col items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-primary dark:hover:text-secondary transition-colors cursor-pointer group"
      >
        <span className="text-sm font-medium">{t("common.next")}</span>
        <svg
          className="w-6 h-6 animate-bounce group-hover:text-primary dark:group-hover:text-secondary"
          fill="none"
          stroke="currentColor"
          viewBox="0 0 24 24"
        >
          <path
            strokeLinecap="round"
            strokeLinejoin="round"
            strokeWidth={2}
            d="M19 14l-7 7m0 0l-7-7m7 7V3"
          />
        </svg>
      </button>
    </section>
  );
};

export default Values1;
