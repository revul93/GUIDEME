import React from "react";
import { useTranslation } from "react-i18next";

const WhoWeAre = () => {
  const { t } = useTranslation();

  return (
    <section
      id="who-we-are"
      className="relative min-h-screen flex items-center justify-center py-12 scroll-mt-20 bg-white dark:bg-gray-900"
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto">
          {/* Section Title */}
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 dark:text-white mb-4">
              {t("whoWeAre.title")}
            </h2>
            <div className="w-24 h-1 bg-primary dark:bg-secondary mx-auto rounded-full"></div>
          </div>

          {/* Content Grid */}
          <div className="grid md:grid-cols-3 gap-8 lg:gap-12">
            {/* Card 1 */}
            <div className="bg-green-100 dark:bg-green-600/60 rounded-2xl p-8 hover:shadow-lg transition-all duration-300 hover:-translate-y-2 text-center">
              <div className="w-16 h-16 bg-primary/10 dark:bg-secondary/10 rounded-xl flex items-center justify-center mb-6 mx-auto">
                <svg
                  className="w-6 h-6 text-primary dark:text-secondary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                {t("whoWeAre.cloud.title")}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {t("whoWeAre.cloud.text")}
              </p>
            </div>

            {/* Card 2 */}
            <div className="bg-pink-100 dark:bg-pink-600/60 rounded-2xl p-8 hover:shadow-lg transition-all duration-300 hover:-translate-y-2 text-center">
              <div className="w-16 h-16 bg-primary/10 dark:bg-secondary/10 rounded-xl flex items-center justify-center mb-6 mx-auto">
                <svg
                  className="w-6 h-6 text-primary dark:text-secondary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                {t("whoWeAre.precision.title")}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {t("whoWeAre.precision.text")}
              </p>
            </div>

            {/* Card 3 */}
            <div className="bg-yellow-100 dark:bg-yellow-600/60 rounded-2xl p-8 hover:shadow-lg transition-all duration-300 hover:-translate-y-2 text-center">
              <div className="w-16 h-16 bg-primary/10 dark:bg-secondary/10 rounded-xl flex items-center justify-center mb-6 mx-auto">
                <svg
                  className="w-6 h-6 text-primary dark:text-secondary"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M13 10V3L4 14h7v7l9-11h-7z"
                  />
                </svg>
              </div>
              <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-4">
                {t("whoWeAre.outcomes.title")}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">
                {t("whoWeAre.outcomes.text")}
              </p>
            </div>
          </div>

          {/* Bottom Statement */}
          <div className="mt-8 text-center">
            <p className="text-lg sm:text-xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto leading-relaxed">
              {t("whoWeAre.statement")}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default WhoWeAre;
