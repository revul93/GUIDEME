import React, { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useLanguage } from "../../context/LanguageContext.jsx";
import SearchIcon from "@mui/icons-material/Search";
import FilterListIcon from "@mui/icons-material/FilterList";
import ChatBubbleIcon from "@mui/icons-material/ChatBubble";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import PersonIcon from "@mui/icons-material/Person";
import LocalHospitalIcon from "@mui/icons-material/LocalHospital";
import VisibilityIcon from "@mui/icons-material/Visibility";
import PriorityHighIcon from "@mui/icons-material/PriorityHigh";
import FolderIcon from "@mui/icons-material/Folder";
import HourglassEmptyIcon from "@mui/icons-material/HourglassEmpty";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import InfoIcon from "@mui/icons-material/Info";
import PaymentIcon from "@mui/icons-material/Payment";
import ThumbUpIcon from "@mui/icons-material/ThumbUp";
import LocalShippingIcon from "@mui/icons-material/LocalShipping";
import DeliveryDiningIcon from "@mui/icons-material/DeliveryDining";

const MyCases = () => {
  const { t } = useTranslation();
  const { language } = useLanguage();

  const [cases, setCases] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [activeFilter, setActiveFilter] = useState("in_progress");
  const [statusCounts, setStatusCounts] = useState({});

  // Filter cards configuration with colors and icons
  const filterCards = [
    {
      id: "all",
      label: t("dashboard.cases.filters.all"),
      icon: FolderIcon,
      bgColor: "bg-gray-100 dark:bg-gray-800",
      activeColor: "bg-gray-500 dark:bg-gray-600",
      textColor: "text-gray-600 dark:text-gray-300",
      activeTextColor: "text-white",
      borderColor: "border-gray-300 dark:border-gray-700",
      activeBorderColor: "border-gray-500 dark:border-gray-600",
    },
    {
      id: "open",
      label: t("dashboard.cases.filters.open"),
      icon: HourglassEmptyIcon,
      bgColor: "bg-yellow-50 dark:bg-yellow-900/20",
      activeColor: "bg-yellow-500 dark:bg-yellow-600",
      textColor: "text-yellow-600 dark:text-yellow-400",
      activeTextColor: "text-white",
      borderColor: "border-yellow-200 dark:border-yellow-800",
      activeBorderColor: "border-yellow-500 dark:border-yellow-600",
    },
    {
      id: "awaiting_payment",
      label: t("dashboard.cases.filters.awaitingPayment"),
      icon: PaymentIcon,
      bgColor: "bg-orange-50 dark:bg-orange-900/20",
      activeColor: "bg-orange-500 dark:bg-orange-600",
      textColor: "text-orange-600 dark:text-orange-400",
      activeTextColor: "text-white",
      borderColor: "border-orange-200 dark:border-orange-800",
      activeBorderColor: "border-orange-500 dark:border-orange-600",
    },
    {
      id: "accepted",
      label: t("dashboard.cases.filters.accepted"),
      icon: ThumbUpIcon,
      bgColor: "bg-sky-50 dark:bg-sky-900/20",
      activeColor: "bg-sky-500 dark:bg-sky-600",
      textColor: "text-sky-600 dark:text-sky-400",
      activeTextColor: "text-white",
      borderColor: "border-sky-200 dark:border-sky-800",
      activeBorderColor: "border-sky-500 dark:border-sky-600",
    },
    {
      id: "in_progress",
      label: t("dashboard.cases.filters.inProgress"),
      icon: AutorenewIcon,
      bgColor: "bg-blue-50 dark:bg-blue-900/20",
      activeColor: "bg-blue-500 dark:bg-blue-600",
      textColor: "text-blue-600 dark:text-blue-400",
      activeTextColor: "text-white",
      borderColor: "border-blue-200 dark:border-blue-800",
      activeBorderColor: "border-blue-500 dark:border-blue-600",
    },
    {
      id: "awaiting_information",
      label: t("dashboard.cases.filters.awaitingInfo"),
      icon: InfoIcon,
      bgColor: "bg-purple-50 dark:bg-purple-900/20",
      activeColor: "bg-purple-500 dark:bg-purple-600",
      textColor: "text-purple-600 dark:text-purple-400",
      activeTextColor: "text-white",
      borderColor: "border-purple-200 dark:border-purple-800",
      activeBorderColor: "border-purple-500 dark:border-purple-600",
    },
    {
      id: "completed_awaiting_pickup",
      label: t("dashboard.cases.filters.awaitingPickup"),
      icon: LocalShippingIcon,
      bgColor: "bg-teal-50 dark:bg-teal-900/20",
      activeColor: "bg-teal-500 dark:bg-teal-600",
      textColor: "text-teal-600 dark:text-teal-400",
      activeTextColor: "text-white",
      borderColor: "border-teal-200 dark:border-teal-800",
      activeBorderColor: "border-teal-500 dark:border-teal-600",
    },
    {
      id: "completed_in_delivery",
      label: t("dashboard.cases.filters.inDelivery"),
      icon: DeliveryDiningIcon,
      bgColor: "bg-cyan-50 dark:bg-cyan-900/20",
      activeColor: "bg-cyan-500 dark:bg-cyan-600",
      textColor: "text-cyan-600 dark:text-cyan-400",
      activeTextColor: "text-white",
      borderColor: "border-cyan-200 dark:border-cyan-800",
      activeBorderColor: "border-cyan-500 dark:border-cyan-600",
    },
    {
      id: "done",
      label: t("dashboard.cases.filters.done"),
      icon: CheckCircleIcon,
      bgColor: "bg-green-50 dark:bg-green-900/20",
      activeColor: "bg-green-500 dark:bg-green-600",
      textColor: "text-green-600 dark:text-green-400",
      activeTextColor: "text-white",
      borderColor: "border-green-200 dark:border-green-800",
      activeBorderColor: "border-green-500 dark:border-green-600",
    },
    {
      id: "cancelled",
      label: t("dashboard.cases.filters.cancelled"),
      icon: CancelIcon,
      bgColor: "bg-red-50 dark:bg-red-900/20",
      activeColor: "bg-red-500 dark:bg-red-600",
      textColor: "text-red-600 dark:text-red-400",
      activeTextColor: "text-white",
      borderColor: "border-red-200 dark:border-red-800",
      activeBorderColor: "border-red-500 dark:border-red-600",
    },
  ];

  // Status configuration for case cards
  const statusConfig = {
    open: {
      color:
        "bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400",
      label: t("dashboard.cases.filters.open"),
    },
    awaiting_payment: {
      color:
        "bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400",
      label: t("dashboard.cases.filters.awaitingPayment"),
    },
    accepted: {
      color: "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400",
      label: t("dashboard.cases.filters.accepted"),
    },
    in_progress: {
      color:
        "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/30 dark:text-indigo-400",
      label: t("dashboard.cases.filters.inProgress"),
    },
    awaiting_information: {
      color:
        "bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400",
      label: t("dashboard.cases.filters.awaitingInfo"),
    },
    completed_awaiting_pickup: {
      color: "bg-teal-100 text-teal-800 dark:bg-teal-900/30 dark:text-teal-400",
      label: t("dashboard.cases.filters.awaitingPickup"),
    },
    completed_in_delivery: {
      color: "bg-cyan-100 text-cyan-800 dark:bg-cyan-900/30 dark:text-cyan-400",
      label: t("dashboard.cases.filters.inDelivery"),
    },
    done: {
      color:
        "bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400",
      label: t("dashboard.cases.filters.done"),
    },
    cancelled: {
      color: "bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400",
      label: t("dashboard.cases.filters.cancelled"),
    },
  };

  // Procedure type labels
  const procedureLabels = {
    single_implant: t("dashboard.cases.procedures.singleImplant"),
    multiple_implant: t("dashboard.cases.procedures.multipleImplant"),
    full_arch: t("dashboard.cases.procedures.fullArch"),
    gbr: t("dashboard.cases.procedures.gbr"),
    others: t("dashboard.cases.procedures.others"),
  };

  // Fetch cases from API
  useEffect(() => {
    fetchCases();
  }, []);

  const fetchCases = async () => {
    setLoading(true);
    setError("");

    try {
      const token = localStorage.getItem("accessToken");

      if (!token) {
        setError(t("dashboard.cases.errors.notAuthenticated"));
        setLoading(false);
        return;
      }

      const response = await fetch("/api/cases/my-cases", {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      });

      // Handle 401 Unauthorized
      if (response.status === 401) {
        localStorage.removeItem("accessToken");
        localStorage.removeItem("refreshToken");
        localStorage.removeItem("user");
        window.location.href = "/";
        return;
      }

      const data = await response.json();

      if (data.success) {
        setCases(data.data.cases);
        setStatusCounts(
          data.data.statusCounts || calculateStatusCounts(data.data.cases)
        );
      } else {
        setError(data.message || t("dashboard.cases.errors.fetchFailed"));
      }
    } catch (err) {
      console.error("Fetch cases error:", err);
      setError(t("dashboard.cases.errors.networkError"));
    } finally {
      setLoading(false);
    }
  };

  // Calculate status counts from cases array
  const calculateStatusCounts = (casesArray) => {
    const counts = { all: casesArray.length };
    casesArray.forEach((c) => {
      counts[c.status] = (counts[c.status] || 0) + 1;
    });
    return counts;
  };

  // Filter cases based on search and status
  const filteredCases = cases.filter((c) => {
    // Status filter
    if (activeFilter !== "all" && c.status !== activeFilter) {
      return false;
    }

    // Search filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      return (
        c.caseNumber?.toLowerCase().includes(query) ||
        c.patientId?.toLowerCase().includes(query) ||
        c.procedureType?.toLowerCase().includes(query)
      );
    }

    return true;
  });

  // Check if case has unread comments
  const hasUnreadComments = (caseItem) => {
    return caseItem.unreadCommentsCount > 0;
  };

  // Format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    return new Intl.DateTimeFormat(language === "ar" ? "ar-SA" : "en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    }).format(date);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-100 dark:bg-gray-950 pt-28 sm:pt-32 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary dark:border-secondary"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-950 pt-8 pb-2">
      <div className="container mx-auto px-4 sm:px-6 lg:px-4">
        {/* Page Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            {t("dashboard.cases.title")}
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-1">
            {t("dashboard.cases.subtitle")}
          </p>
        </div>

        {/* Main Content Card */}
        <div className="bg-white dark:bg-gray-900 rounded-2xl shadow-lg p-6">
          {/* Filter Cards - 4 per row on mobile, smaller cards */}
          <div className="grid grid-cols-4 sm:grid-cols-5 lg:grid-cols-10 gap-2 sm:gap-3 mb-6">
            {filterCards.map((filter) => {
              const Icon = filter.icon;
              const isActive = activeFilter === filter.id;
              const count = statusCounts[filter.id] || 0;

              return (
                <button
                  key={filter.id}
                  onClick={() => setActiveFilter(filter.id)}
                  className={`relative p-2 sm:p-3 rounded-lg sm:rounded-xl border-2 transition-all duration-200 hover:shadow-md ${
                    isActive
                      ? `${filter.activeColor} ${filter.activeBorderColor} ${filter.activeTextColor}`
                      : `${filter.bgColor} ${filter.borderColor} ${filter.textColor} hover:border-opacity-70`
                  }`}
                >
                  <div className="flex flex-col items-center text-center">
                    <Icon
                      className={`w-4 h-4 sm:w-5 sm:h-5 mb-1 ${
                        isActive ? filter.activeTextColor : ""
                      }`}
                    />
                    <span className="text-[10px] sm:text-xs font-medium mb-0.5 leading-tight line-clamp-1">
                      {filter.label}
                    </span>
                    <span
                      className={`text-sm sm:text-lg font-bold ${
                        isActive ? filter.activeTextColor : ""
                      }`}
                    >
                      {count}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Search Box */}
          <div className="relative mb-6">
            <SearchIcon className="absolute left-4 rtl:left-auto rtl:right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t("dashboard.cases.searchPlaceholder")}
              className="w-full pl-12 rtl:pl-4 rtl:pr-12 pr-4 py-3 border border-gray-300 dark:border-gray-700 rounded-xl bg-gray-50 dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-primary dark:focus:ring-secondary focus:border-transparent transition-colors"
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="mb-6 p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
              <p className="text-sm text-red-600 dark:text-red-400">{error}</p>
            </div>
          )}

          {/* Cases List */}
          {filteredCases.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 dark:bg-gray-800 rounded-full flex items-center justify-center">
                <FilterListIcon className="w-8 h-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                {t("dashboard.cases.noCases")}
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                {searchQuery
                  ? t("dashboard.cases.noSearchResults")
                  : t("dashboard.cases.noCasesDescription")}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
              {filteredCases.map((caseItem) => (
                <div
                  key={caseItem.id}
                  className={`relative bg-gray-50 dark:bg-gray-800 rounded-xl p-5 border-2 transition-all hover:shadow-lg hover:-translate-y-1 ${
                    hasUnreadComments(caseItem)
                      ? "border-red-300 dark:border-red-700 bg-red-50/50 dark:bg-red-900/10"
                      : "border-transparent"
                  }`}
                >
                  {/* Unread Indicator */}
                  {hasUnreadComments(caseItem) && (
                    <div className="absolute top-3 right-3 rtl:right-auto rtl:left-3">
                      <span className="flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-red-500"></span>
                      </span>
                    </div>
                  )}

                  {/* Priority Badge */}
                  {caseItem.priority === "urgent" && (
                    <div className="absolute top-3 left-3 rtl:left-auto rtl:right-3">
                      <span className="flex items-center gap-1 px-2 py-1 bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 text-xs font-medium rounded-full">
                        <PriorityHighIcon className="w-3 h-3" />
                        {t("dashboard.cases.urgent")}
                      </span>
                    </div>
                  )}

                  {/* Case Number & Status */}
                  <div className="flex items-start justify-between mb-3 mt-2">
                    <span className="text-sm font-mono text-gray-500 dark:text-gray-400">
                      #{caseItem.caseNumber}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        statusConfig[caseItem.status]?.color ||
                        "bg-gray-100 text-gray-800"
                      }`}
                    >
                      {statusConfig[caseItem.status]?.label || caseItem.status}
                    </span>
                  </div>

                  {/* Patient ID */}
                  <div className="flex items-center gap-2 mb-2">
                    <PersonIcon className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {caseItem.patientId || t("dashboard.cases.noPatientId")}
                    </span>
                  </div>

                  {/* Procedure Type */}
                  <div className="flex items-center gap-2 mb-2">
                    <LocalHospitalIcon className="w-4 h-4 text-gray-400" />
                    <span className="text-sm font-medium text-gray-900 dark:text-white">
                      {procedureLabels[caseItem.procedureType] ||
                        caseItem.procedureType}
                    </span>
                  </div>

                  {/* Created Date */}
                  <div className="flex items-center gap-2 mb-4">
                    <AccessTimeIcon className="w-4 h-4 text-gray-400" />
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {formatDate(caseItem.createdAt)}
                    </span>
                  </div>

                  {/* Footer: Comments & View Button */}
                  <div className="flex items-center justify-between pt-4 border-t border-gray-200 dark:border-gray-700">
                    {/* Comments Count */}
                    <div className="flex items-center gap-2">
                      <ChatBubbleIcon
                        className={`w-4 h-4 ${
                          hasUnreadComments(caseItem)
                            ? "text-red-500"
                            : "text-gray-400"
                        }`}
                      />
                      <span
                        className={`text-sm ${
                          hasUnreadComments(caseItem)
                            ? "text-red-600 dark:text-red-400 font-medium"
                            : "text-gray-600 dark:text-gray-400"
                        }`}
                      >
                        {caseItem.commentsCount || 0}{" "}
                        {t("dashboard.cases.comments")}
                        {hasUnreadComments(caseItem) && (
                          <span className="ml-1 rtl:ml-0 rtl:mr-1">
                            ({caseItem.unreadCommentsCount}{" "}
                            {t("dashboard.cases.unread")})
                          </span>
                        )}
                      </span>
                    </div>

                    {/* View Button */}
                    <button
                      onClick={() => {
                        window.location.href = `/dashboard/case/${caseItem.id}`;
                      }}
                      className="flex items-center gap-1 px-3 py-1.5 bg-primary hover:bg-primary-dark dark:bg-secondary dark:hover:bg-secondary-dark text-white text-sm font-medium rounded-lg transition-colors"
                    >
                      <VisibilityIcon className="w-4 h-4" />
                      {t("dashboard.cases.view")}
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MyCases;
